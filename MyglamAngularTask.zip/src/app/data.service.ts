import { Injectable } from '@angular/core';
import {Http,Response,Headers,RequestOptions} from '@angular/http';
import 'rxjs/add/operator/map';
import { Observable } from "rxjs/Rx";

@Injectable()
export class DataService {
  url : string;
  headers : any = new Headers();
  constructor(private _http:Http) {
    this.headers.append('Content-Type','application/json');
    this.url = 'http://localhost:8080/services/UserOperation';
   }
  
  //GET request to retrive list of data from server
  getEmployeeList(){
    return this._http.get(this.url).map((res:Response) => res.json()).catch((err) => {
      return Observable.throw(err);
    });
  }

  //POST request to submit data
  postFormData(params){
    return this._http.post(this.url,params,{headers : this.headers}).map((res:Response) => res.json()).catch((err) => {
      return Observable.throw(err);
    });
  }

  //PUT request to perform updation on server side
  putFormData(params){
    return this._http.put(this.url,params,{headers : this.headers}).map((res:Response) => res.json()).catch((err) => {
      return Observable.throw(err);
    });
  }

  //DELETE request to delete resource
  deleteFormData(params){
    return this._http.delete(this.url,{headers : this.headers,body:params}).map((res:Response) => res.json()).catch((err) => {
      return Observable.throw(err);
    });
  }
}
