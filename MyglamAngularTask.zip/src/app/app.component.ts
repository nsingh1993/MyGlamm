import { Component,ViewChild, ElementRef } from '@angular/core';
import { DataService } from './data.service';
import {Http,Response,Headers,RequestOptions} from '@angular/http';
import { Observable } from 'rxjs/Rx';
import {NgForm} from '@angular/forms';


declare var $: any;

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css'],
  providers:[DataService]
})
export class AppComponent {
  private model:any={};
  private employees:any;
  showError : boolean;
  @ViewChild('frm') public userFrm: NgForm;

  //private courses:any;
  constructor(private dataService:DataService) { 
    this.dataService = dataService;
  }

  ngOnInit() {
    this.model.id = "";
    this.model.name="";
    this.model.contact="";
    this.model.email="";
    this.callHttpGetMethod();
  }
  
  callHttpGetMethod() : void {
    this.dataService.getEmployeeList().subscribe(p =>{
      this.employees = p.Result;
      this.showError = (this.employees.length == 0);
    },
    error => alert(error),
    () => console.log('get success'));
  }
  
  callHttpPostMethod() : void {
    var params = this.model;
    this.dataService.postFormData(params)
    .subscribe(p => {
      this.callHttpGetMethod();
      this.clearModelData();
      $('#myAddModal').modal('hide');
    },
    error => {
      alert(error);
      this.clearModelData();
    },
    ()=> console.log('post success'));
  }

  setModelData(index) : void {
    this.model.id = this.employees[index].id;
    this.model.name = this.employees[index].name;
    this.model.contact = this.employees[index].contact;
    this.model.email = this.employees[index].email;
  }

  clearModelData() : void {
    this.model.id = '';
    this.model.name = '';
    this.model.contact = '';
    this.model.email = '';
    this.userFrm.resetForm(true);
  }
  removeFocus(){
    $( 'button[class*="add"]' ).focus(function() {
      this.blur();
  });
   $( 'button[class*="edit"]' ).focus(function() {
      this.blur();
  });
  $( 'button[class*="delete"]' ).focus(function() {
      this.blur();
  });
  }
  callHttpPutMethod() : void {
    var params = this.model;
    this.dataService.putFormData(params)
    .subscribe(p => {
      this.callHttpGetMethod();
      this.clearModelData();
      $('#myEditModal').modal('hide');
    },
    error => {
      alert("error :"+error);
      this.clearModelData();
    }
  );
    
  }

  callHttpDeleteMethod() : void {
    var params = this.model;
    this.dataService.deleteFormData(params)
    .subscribe(p => {
      this.callHttpGetMethod();
      this.clearModelData();
      $('#myDeleteModal').modal('hide');
    },
    error => {
      alert('error :'+error);
      this.clearModelData();
    },
    ()=> console.log('delete success'));
  }
}
