import { MyglamAngularTaskPage } from './app.po';

describe('myglam-angular-task App', function() {
  let page: MyglamAngularTaskPage;

  beforeEach(() => {
    page = new MyglamAngularTaskPage();
  });

  it('should display message saying app works', () => {
    page.navigateTo();
    expect(page.getParagraphText()).toEqual('app works!');
  });
});
